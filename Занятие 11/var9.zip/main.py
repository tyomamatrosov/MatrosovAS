import tkinter as tk
import requests
import json

def get_repository_info():
    repo_name = repo_name_entry.get()
    url = f'https://api.github.com/repos/{repo_name}'
    response = requests.get(url)


    data = response.json()
    info = {
    'company': data.get('owner', {}).get('company'),
    'created_at': data.get('created_at'),
    'email': data.get('owner', {}).get('email'),
    'id': data.get('id'),
    'name': data.get('name'),
    'url': data.get('owner', {}).get('url')
    }
    with open('repository_info.json', 'w') as file:
        json.dump(info, file, indent=4)
# Создание окна
window = tk.Tk()
window.title("GitHub Repository Info")

# Создание и размещение элементов
repo_name_label = tk.Label(window, text="Имя репозитория (например, 'kubernetes/kubernetes'): ")
repo_name_label.pack()

repo_name_entry = tk.Entry(window)
repo_name_entry.pack()

get_info_button = tk.Button(window, text="Получить информацию", command=get_repository_info)
get_info_button.pack()

result_label = tk.Label(window, text="")
result_label.pack()

# Запуск главного цикла
window.mainloop()